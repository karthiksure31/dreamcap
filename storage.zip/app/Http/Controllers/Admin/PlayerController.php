<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Players;
use App\Models\Positions;
use App\Models\Series;
use App\Models\Teams;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\DB;

class PlayerController extends Controller
{
    //
    function playersIndex()
    {
        $series = Series::select('id', 'series_name')->get();
        $teams = Teams::select('id', 'team_name')->get();
        $positions = Positions::select('id', 'position_name')->get();
        return view(
            'admin.players.index',
            [
                'series' => $series,
                'teams' => $teams,
                'positions' => $positions
            ]
        );
    }
    // get list of players
    function getPlayerList(Request $request)
    {
        // $getPlayers = Players::all();
        // dd($getPlayers);
        $getPlayers =  DB::table('players as pl')
            ->select(
                'pl.id',
                'pl.player_name',
                'pl.credit_points',
                'ps.id as position_id',
                'ps.position_name',
                't.id as team_id',
                't.team_name',
                's.id as series_id',
                's.series_name',
            )
            ->leftjoin('teams as t', 't.id', '=', 'pl.team_id')
            ->leftjoin('series as s', 's.id', '=', 'pl.series_id')
            ->leftjoin('positions as ps', 'ps.id', '=', 'pl.position_id')
            ->where('pl.status','0')
            ->get();

        // $resultArray =   json_encode($getPlayers);
        // return $getPlayers;
        return DataTables::of(json_decode($getPlayers, true))
            ->addIndexColumn()
            ->addColumn('actions', function ($row) {
                return '<div class="btn-group">
                                                <button class="btn btn-sm btn-primary" data-id="' . $row['id'] . '" id="editPlayerBtn">Update</button>
                                                <button class="btn btn-sm btn-danger" data-id="' . $row['id'] . '" id="deletePlayerBtn">Delete</button>
                                          </div>';
            })
            ->rawColumns(['actions'])
            ->make(true);
    }
    // get row details
    public function getPlayerDetails(Request $request)
    {
        $id = $request->id;
        $playerDetails = Players::find($id);
        return response()->json(['details' => $playerDetails]);
    }
    // add players
    public function addPlayer(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'player_name' => 'required',
            'credit_points' => 'required',
            'series_id' => 'required',
            'team_id' => 'required',
            'position_id' => 'required'
        ]);

        $players = new Players();
        $players->player_name = $request->player_name;
        $players->credit_points = $request->credit_points;
        $players->series_id = $request->series_id;
        $players->team_id = $request->team_id;
        $players->position_id = $request->position_id;
        $query = $players->save();

        if (!$query) {
            return response()->json(['code' => 500, 'message' => 'Something went wrong']);
        } else {
            return response()->json(['code' => 200, 'message' => 'New Player has been successfully saved']);
        }
    }
    // updatePlayer
    public function updatePlayer(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'id' => 'required',
            'player_name' => 'required',
            'credit_points' => 'required',
            'series_id' => 'required',
            'team_id' => 'required',
            'position_id' => 'required'
        ]);

        $players = Players::find($request->id);
        $players->player_name = $request->player_name;
        $players->status = "0";
        $players->credit_points = $request->credit_points;
        $players->series_id = $request->series_id;
        $players->team_id = $request->team_id;
        $players->position_id = $request->position_id;
        $query = $players->save();

        if ($query) {
            return response()->json(['code' => 200, 'message' => 'New Player has been successfully updated']);
        } else {
            return response()->json(['code' => 500, 'message' => 'Something went wrong']);
        }
    }
    // deletePlayer
    public function deletePlayer(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'id' => 'required'
        ]);

        $players = Players::find($request->id);
        $players->status = "1";
        $query = $players->save();

        if ($query) {
            return response()->json(['code' => 200, 'message' => 'New Player has been successfully deleted']);
        } else {
            return response()->json(['code' => 500, 'message' => 'Something went wrong']);
        }
    }
}
